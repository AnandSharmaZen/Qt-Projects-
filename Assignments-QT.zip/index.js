/* Question 1


function fibonacci(n) {
  if (n === 0) {
    return [];
  } else if (n === 1) {
    return [0];
  } else if (n === 2) {
    return [0, 1];
  } else {
    const sequence = [0, 1];
    for (let i = 2; i < n; i++) {
      const nextValue = sequence[i - 1] + sequence[i - 2];
      sequence.push(nextValue);
    }
    return sequence;
  }
}

const sequenceLength = 10;
const fibonacciSequence = fibonacci(sequenceLength);
console.log(`Fibonacci sequence of length ${sequenceLength}:`, fibonacciSequence);
*/




/* Question 2


function outer() {

var x = 10;

function inner() {

console.log(x);

}

return inner;

}

var innerFunc = outer();

innerFunc();
*/


/* Question 3


const sampleArray = [1, 2, 3, 4, 5, 6];

// Using for loop
console.log("Using for loop:");
for (let i = 0; i < sampleArray.length; i++) {
  console.log(sampleArray[i]);
}

// Using while loop
console.log("Using while loop:");
let index = 0;
while (index < sampleArray.length) {
  console.log(sampleArray[index]);
  index++;
}

// Using do...while loop
console.log("Using do...while loop:");
let anotherIndex = 0;
do {
  console.log(sampleArray[anotherIndex]);
  anotherIndex++;
} while (anotherIndex < sampleArray.length);
*/





/* Question 4

function mul(x) {
  return function(y) {
    return function(z) {
      return x * y * z;
    };
  };
}

const result = mul(3)(4)(2);
console.log(result); 

*/




 /* Question 5

const sampleObject = { a: 10, b: 20, c: { x: 10, y: 20 } };

// Using for...in loop (iterates over enumerable properties)
console.log("Using for...in loop:");
for (const key in sampleObject) {
  console.log(key, sampleObject[key]);
}

// Using Object.keys() to get keys and iterate
console.log("Using Object.keys():");
const keys = Object.keys(sampleObject);
for (const key of keys) {
  console.log(key, sampleObject[key]);
}

// Using Object.values() to get values and iterate
console.log("Using Object.values():");
const values = Object.values(sampleObject);
for (const value of values) {
  console.log(value);
}

// Using Object.entries() to get key-value pairs and iterate
console.log("Using Object.entries():");
const entries = Object.entries(sampleObject);
for (const [key, value] of entries) {
  console.log(key, value);
}

// Using forEach() on Object.keys()
console.log("Using forEach() on Object.keys():");
Object.keys(sampleObject).forEach(key => {
  console.log(key, sampleObject[key]);
});
*/










































/* Question : 7
/*a = 5;
console.log(a);
var a; // 5 hoisting done

b = 5;
console.log(b); // reference error
let b; // hoisting not allowed

c = 5;
console.log(c) // syntax error
const c; // hoisting not allowed
*/




/*Question : 8
let text1 = "test";
let text2 = "plugin";
let result = text1.concat( " ", text2)
console.log(result);*/


/* Question : 8(b)

let text1 = "test";
let text2 = "plugin";
let result = text1+text2
console.log(result);*/

/*Question : 8 (c)
const elements = ['test','plugin','java'];
console.log(elements.join(''));
*/




/*Question : 9

let employee = [
  {
    "id" : 11,
    "name" : "Abhinav",
    "salary" : 75000
  },
  
  {
    "id" : 2131,
    "name" : "Raj",
    "salary" : 62000
  },

  {
    "id" : 3202,
    "name" : "Rahul",
    "salary" : 32000
  }]
console.log(employee.map(getempid));
function getempid(emp) {
  return emp.id;
}
*/




/*Question 10

let employees = [
  {
    "id" : 11,
    "name" : "Abhinav",
    "salary" : 75000
  },
  
  {
    "id" : 2131,
    "name" : "Raj",
    "salary" : 62000
  },

  {
    "id" : 3202,
    "name" : "Rahul",
    "salary" : 32000
  }]
console.log(employees.filter(getsal));

function getsal(emp) {
  return emp.salary>= 30000;
}
*/




/*Question 11

let employees = [
  {
    "id" : 11,
    "name" : "Abhinav",
    "salary" : 75000
  },
  
  {
    "id" : 2131,
    "name" : "Raj",
    "salary" : 62000
  },

  {
    "id" : 3202,
    "name" : "Rahul",
    "salary" : 32000
  }]
console.log(employees.find(getid));

function getid(emp) {
  return emp.id= 3012;
  
}
*/




/* Question 12

for (var i = 0; i < 3; i++) {
  setTimeout(function() { alert(i); }, 1000 + i );
  
}
*/









/* Question 15

const object = {
  
  message: 'Hello, World!',

  getMessage() {
    const message = 'Hello, Earth!';
      return this.message; 
}
};

console.log(object.getMessage());

*/

/*Question 16

function sayHello() {
  console.log(this.message);
}

const helloObject = {
  message: "Hello, World!",
};

// Using call
sayHello.call(helloObject);

// Using apply 
sayHello.apply(helloObject, []);

// Using bind
const helloFunction = sayHello.bind(helloObject);
helloFunction();
*/




/* Question 17


const object = {
who: 'World',

greet() {
return `Hello, ${this.who}!`;
},

farewell: () => {
return `Goodbye, ${this.who}!`;
}
};

console.log(object.greet()); 
console.log(object.farewell()); 

*/









  








        
